/*
 * Copyright (C) 2015 Ondra
 *
 */
package exception;

/**
 *
 * @author Ondra
 */
public class InvalidInputException extends Exception {

  public InvalidInputException(String message){
     super(message);
  }
}
