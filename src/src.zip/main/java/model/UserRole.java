package model;

/**
 *
 */
public enum UserRole {

    GUEST,
    ADMIN
}
