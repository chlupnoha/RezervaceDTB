package model;

/**
 *
 */
public enum Confirmed {

    CONFIRMED,
    NOT_CONFIRMED

}
