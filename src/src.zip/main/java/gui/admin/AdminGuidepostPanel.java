package gui.admin;

import gui.ManagedCard;

/**
 * Created by marek on 5.5.16.
 */
public class AdminGuidepostPanel extends ManagedCard {

    {
        setupComponents();
    }

    @Override
    public void setupComponents() {

    }
}
