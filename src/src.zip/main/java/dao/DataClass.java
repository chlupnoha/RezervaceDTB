
package dao;

/**
 * Table class for non asign table
 */
public interface DataClass {

    Long getId();

    void setId(Long id);
}
